// Clave secreta utilizada para cifrar y descifrar datos
export const secretKey = 'c2aaf606768e007e59fcbd4ff70717a7fddcc82fca0dff1c089a42f798c6fd00';
