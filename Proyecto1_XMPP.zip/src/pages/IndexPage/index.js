import IndexPage from './IndexPage';

export default IndexPage;
